package fr.tosmoth.applicationpendu;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.MediaPlayer;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private LinearLayout container;
    private Button btn_send;
    private TextView lettres_tapees;
    private ImageView image;
    private EditText letter;
    private String word;
    private int found;
    private int error;
    private List<Character> listOfLetters = new ArrayList<>();
    private boolean win;
    private List<String> wordList = new ArrayList<>();
    private Button btn_pos;
    private MediaPlayer mediaPlayer;
    private SeekBar seekbar;
    public static final int REQUEst_CAPTURE = 1;
    public ImageView resultat_photo;
    private TextView txt;
    private SensorManager sensorManager;
    private Sensor pressureSensor;

    //Gyroscope
    private SensorEventListener sensorEventListener = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent sensorEvent) {
            float[] values = sensorEvent.values;
            txt.setText(String.format("%.3f mbar", values[0]));
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int i) {

        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        container = findViewById(R.id.word_container);
        btn_send = findViewById(R.id.btn_send);
        letter = findViewById(R.id.et_letter);
        image = findViewById(R.id.id_pendu);
        lettres_tapees = findViewById(R.id.tv_letter);

        initGame();

        btn_send.setOnClickListener(this);

        this.seekbar = (SeekBar) findViewById(R.id.sound_bar);

        this.mediaPlayer = MediaPlayer.create(getApplicationContext(),R.raw.son);

        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                seekbar.setProgress(mediaPlayer.getCurrentPosition() / 1000);

            }
        },1000, 1000);

        seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                mediaPlayer.seekTo(seekBar.getProgress() * 1000);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        Button click = (Button)findViewById(R.id.btnCamera);
        resultat_photo = (ImageView)findViewById(R.id.imageView);

        if(!hasCamera()){
            click.setEnabled(false);
        }

        txt = findViewById(R.id.txt);
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        pressureSensor = sensorManager.getDefaultSensor(Sensor.TYPE_PRESSURE);

        btn_pos = findViewById(R.id.btn_pos);
        btn_pos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGPSActivity();
            }
        });

    }

    public void openGPSActivity(){
        Intent intent = new Intent(this, GPSActivity.class);
        startActivity(intent);
    }

    @Override
    protected void onResume(){
        super.onResume();
        sensorManager.registerListener(sensorEventListener, pressureSensor, SensorManager.SENSOR_DELAY_UI);

    }

    @Override
    protected void onPause(){
        super.onPause();
        sensorManager.unregisterListener(sensorEventListener);

    }

    public boolean hasCamera(){
        return getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY);
    }

    public void launchCamera(View view){
        Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(i, REQUEst_CAPTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        if(requestCode == REQUEst_CAPTURE && resultCode ==RESULT_OK){
            Bundle extras = data.getExtras();
            Bitmap photo = (Bitmap) extras.get("data");
            resultat_photo.setImageBitmap(photo);

        }
    }

    public void playSound(View view){
        Button button = (Button) view;

        if(mediaPlayer.isPlaying()){
            mediaPlayer.pause();
            button.setText(getString(R.string.play_music_btn));
        }

        else{
            mediaPlayer.start();
            button.setText(getString(R.string.pause_music_btn));
        }
    }

    public void initGame(){

        word = generateWord();
        win = false;
        error = 0;
        found = 0;
        lettres_tapees.setText("");
        image.setBackgroundResource(R.drawable.first);
        listOfLetters = new ArrayList<>();

        container.removeAllViews();

        for(int i = 0; i<word.length();i++)
        {
            TextView oneLetter = (TextView) getLayoutInflater().inflate(R.layout.textview, null);
            container.addView(oneLetter);
        }



    }


    @Override
    public void onClick(View v) {

        String letterFromInput = letter.getText().toString().toUpperCase();
        letter.setText("");

        if(letterFromInput.length() > 0){
            if(!letterAlreadyUsed(letterFromInput.charAt(0), listOfLetters)){
                listOfLetters.add(letterFromInput.charAt(0));
                checkLetter(letterFromInput, word);
            }

            if(found == word.length()){
                win = true;
                createDialog(win);
            }

            if(!word.contains(letterFromInput)){
                error++;
            }

            setImage(error);
            if(error == 6){
                win = false;
                createDialog(win);
            }

            showAllLetters(listOfLetters);

        }


    }

    public boolean letterAlreadyUsed(char a, List<Character> listOfLetters){
        for(int i = 0; i < listOfLetters.size(); i++){

            if(listOfLetters.get(i) == a){
                Toast.makeText(getApplicationContext(), "Vous avez déjà enré cette lettre", Toast.LENGTH_SHORT).show();
                return true;
            }
        }
        return false;
    }

    public void checkLetter(String letter, String word){

        for(int i = 0; i < word.length(); i++){
            if(letter.equals(String.valueOf(word.charAt(i)))){
                TextView tv = (TextView) container.getChildAt(i);
                tv.setText((String.valueOf(word.charAt(i))));
                found++;

        }
        }
    }

    public void showAllLetters(List<Character> listOfLetters){
        String chaine = "";

        for(int i = 0; i < listOfLetters.size(); i++){
            chaine += listOfLetters.get(i) + "\n";

        }
        if(!chaine.equals("")){
            lettres_tapees.setText(chaine);
        }
    }

    public void setImage(int error){

        switch(error){
            case 1 :
                image.setBackgroundResource(R.drawable.second);
                break;
            case 2 :
                image.setBackgroundResource(R.drawable.third);
                break;
            case 3 :
                image.setBackgroundResource(R.drawable.fourth);
                break;
            case 4 :
                image.setBackgroundResource(R.drawable.fifth);
                break;
            case 5 :
                image.setBackgroundResource(R.drawable.sixth);
                break;
            case 6 :
                image.setBackgroundResource(R.drawable.seventh);
                break;
        }
    }

    public void createDialog(boolean win){

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Win");

        if(!win){
            builder.setTitle("You Loose");
            builder.setMessage("Le mot à trouver était : " + word);
        }
        builder.setPositiveButton(getString(R.string.Rejouer), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                initGame();
            }
        });

        builder.create().show();
    }

    public List<String> getListOfWords(){

        try {
            BufferedReader buffer = new BufferedReader(new InputStreamReader(getAssets().open("pendu_liste.txt")));
            String line;
            while((line = buffer.readLine()) != null){
                wordList.add(line);
            }
            buffer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return wordList;

    }

    public String generateWord(){
        wordList = getListOfWords();
        int random = (int) (Math.floor(Math.random()* wordList.size()));
        String word = wordList.get(random).trim();
        return word;
    }

    boolean doubleTap = false;

    public void onBackPressed(){
        if (doubleTap){
            super.onBackPressed();
        }else{
            Toast.makeText(this, "Double tap pour quitter l'appli",Toast.LENGTH_SHORT).show();
            doubleTap =true;
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    doubleTap = false;
                }
            },500);


        }
    }

}


